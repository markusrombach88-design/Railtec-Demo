# RailTech AI – iPhone-Demo (kostenlos)

Diese öffentliche Demo nutzt ausschließlich fest eingebaute, fiktive Beispieldaten. Sie ist **nicht** der vollständige lokale Prototyp v0.1: Keine Benutzerkonten, keine Uploads, keine echte KI. Es ist eine durchsuchbare mobile Oberfläche.

## Kostenlos veröffentlichen

1. GitHub-Konto erstellen oder anmelden.
2. Neues Repository `railtech-ai-demo` anlegen (für Streamlit Community Cloud öffentliches Repository).
3. `app.py` und `requirements.txt` aus diesem Ordner ins Repository hochladen.
4. Unter https://share.streamlit.io/ mit GitHub anmelden und „Create app“ / „Deploy a public app from GitHub“ wählen.
5. Repository, Branch `main` und Hauptdatei `app.py` auswählen; bereitstellen.
6. Den erzeugten `*.streamlit.app`-Link auf dem iPhone in Safari öffnen. Über Teilen > Zum Home-Bildschirm ein App-Symbol anlegen.

Die App wird erst nach diesen Schritten öffentlich erreichbar. Kostenlose Dienste können schlafen gehen oder ihre Nutzungsbedingungen ändern.

**Datenschutz:** Kein Firmenmaterial, keine echten Namen, keine Passwörter oder personenbezogenen Daten in die Demo eintragen. Streamlit Community Cloud ist kein freigegebenes Firmen-Dokumentenarchiv. Für Mehrbenutzerbetrieb mit vertraulichen Unterlagen braucht es einen anderen, abgesicherten Aufbau.
